import cv2

def encrypt(image_path, message, password, output_path="encrypted_image.png"):
    """Encrypts a message into an image."""
    img = cv2.imread(image_path)
    if img is None:
        print("Error: Could not load image.")
        return

    message_len = len(message)
    if message_len > img.shape[0] * img.shape[1] * 3:
        print("Error: Message too large for image.")
        return

    char_to_ascii = {chr(i): i for i in range(256)}
    row, col, channel = 0, 0, 0

    for char in message:
        img[row, col, channel] = char_to_ascii[char]
        channel = (channel + 1) % 3
        if channel == 0:
            col += 1
            if col == img.shape[1]:
                col = 0
                row += 1

    cv2.imwrite(output_path, img)
    print(f"Encryption complete. Image saved to {output_path}")

if __name__ == "__main__":
    image_file = input("Enter image path: ")
    secret_message = input("Enter secret message: ")
    encryption_password = input("Enter encryption password: ")
    encrypt(image_file, secret_message, encryption_password)
    
