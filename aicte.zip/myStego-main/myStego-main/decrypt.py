import cv2

def decrypt(encrypted_image_path, password, message_length):
    """Decrypts a message from an encrypted image."""
    img = cv2.imread(encrypted_image_path)
    if img is None:
        print("Error: Could not load encrypted image.")
        return

    ascii_to_char = {i: chr(i) for i in range(256)}
    row, col, channel = 0, 0, 0
    decrypted_message = ""

    entered_password = input("Enter decryption password: ")

    if entered_password == password:
        for _ in range(message_length):
            decrypted_message += ascii_to_char[img[row, col, channel]]
            channel = (channel + 1) % 3
            if channel == 0:
                col += 1
                if col == img.shape[1]:
                    col = 0
                    row += 1
        print("Decrypted message:", decrypted_message)
    else:
        print("Incorrect password.")

if __name__ == "__main__":
    encrypted_file = input("Enter encrypted image path: ")
    original_message_len = int(input("Enter original message length: "))
    decryption_password = input("Enter decryption password: ")
    decrypt(encrypted_file, decryption_password, original_message_len)
